Hellocare iOS SDK QuickStart
================

Follow this documentation to integrate Hellocare iOS SDK in your project or just use our example app. 

Get started with the SDK :

- [Requirements](#Requirements) - Requirements
- [Quickstart](#Quickstart with example app) - Run the quickstart app
- [Include in iOS project](#Framework Installation) - Install the HellocareSDK in your app
- [Usage](#Usage) - Use the HellocareSDK in your app

## Requirements

This sdk is build with swift version 4.2 and support iOS 10.0 and later

This SDK need some permissions to add to your info.plist to run properly:
```
NSCameraUsageDescription
NSMicrophoneUsageDescription
```

## Quickstart with example app

To get started with the Quickstart application follow theses steps:

1. Open this project in Xcode and select run the DemoApp.
2. On the main page of the app enter your API KEY provided by Hellocare (dev or Prod)
3. Run your session


## Framework Dependancy for iOS

This framework is based on TwilioVideo and PusherSwift framework. In top of that, PusherSwift depends on Starscream, TaskQueue, ReachabilitySwift and CryptoSwift frameworks. Hellocare provides the right version of each of those frameworks.

## Framework Installation

CocoaPods

CocoaPods is a dependency manager for Cocoa projects and is our recommended method of installing HellocareSDK and its dependencies.

If you don't already have the Cocoapods gem installed, run the following command:

$ gem install cocoapods
To integrate HellocareSDK into your Xcode project using CocoaPods, specify it in your Podfile:

source 'https://github.com/CocoaPods/Specs.git'
platform :ios, '10.0'
use_frameworks!

pod 'HellocareSDK'
Then, run the following command:

$ pod install
If you find that you're not having the most recent version installed when you run pod install then try running:

$ pod cache clean
$ pod repo update HellocareSDK
$ pod install

Also you'll need to make sure that you've not got the version of HellocareSDK locked to an old version in your Podfile.lock file.

#####Current sdk version : 1.0.3

## Usage

#### Initialization 

You need to enter your API key provided by Hellocare to use this sdk.

Initialize the Hellocare SDK in your Application class with your API KEY.
The API KEY cannot be null or empty. If you put an empty API Key an IllegalStateException is raised.

```

func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
........
HellocareSDK.setup(apiKey:String, sessionToken: String)
........
}

```

#### Connexion process

The connexion process is a sequence of differents states. 
The basic workflow is :

```
Setup -> Connect  -> StartEncounterVideo

```

###### Starting the workflow

You need to call goToConnectingState() to start the session process.
```
HellocareSDK.shared.goToConnectingState() 
```
###### Stop the worklow

You can cancel the session workflow when you want before the video with the ```cancel()```.
```
HellocareSDK.shared.cancelSession() 
``` 

The callback ```onCancelSessionSuccess()``` is called on success.

The callback ```onSessionError(sessionError:SessionError)``` is called when errors occurs with 
the error information

##### Workflow details

The callback ```onConnectingStateSuccess()``` is called on connexion successfull.

The callback ```onSessionError(sessionError: SessionError)``` is called when errors occurs with 
the error information

From this state you can go only to the Dispatching state or doctor missing state when
no doctor available

```
HellocareSDK.shared.goToDispatchingState() 
```

The callback ```onDispatchingStateSuccess()``` is called on dispatching successfull and a doctor 
is available

The callback ```onDoctorMissingState()``` is called when no doctor available
From this state you can go only cancel the session because no doctor available.

The callback ```onSessionError(sessionError:SessionError)``` is called when errors occurs with 
the error information

From the dispatching success state you can go only to the joining state   
```
HellocareSDK.shared.goToJoinState() 
```
On joining success the callback ```onJoinStateSuccess(assignedDoctor:AssignedDoctor, awaitingTime:Double)``` 
is called on success with doctor informations and estimated video start time in minutes.

From this state when the doctor is ready to start the consultation the callback 
```onVideoReadyToStart()``` is called.

#### When ```onVideoReadyToStart()``` raised, you can start your video session.


#####Simple process implementation : 

```  
func startSession(){  
HellocareSDK.shared.goToConnectingState()
}

func onConnectingStateSuccess() {
HellocareSDK.shared.goToDispatchState()
}

func onDispatchingStateSuccess() {
HellocareSDK.shared.goToJoinState()
}

func onJoinStateSuccess(assignedDoctor:AssignedDoctor, awaitingTime:Double) {
//receive the assigned doctor and an estimated time in minutes before the video session start
//the session can start before the end of this time if the method onVideoReadyToStart() raised
//call startVideoSession with a VideoSessionListener to see the patient local camera during the wait
}

func onSessionError(sessionError:SessionError) {
// do your error  stuff
}

func onDoctorMissingState() {
updateOnDoctorMissingState()
}

func onVideoReadyToStart() {
//The doctor was connected and will start the video call
}

func onCancelSessionSuccess() {
//handle cancel success
}
```


#### Video Session

When all connection steps have been successful you can start your video session. You can add set a view as a VideoSessionView to your storyboard (don't forget to select the module in Interfacebuilder under the class. Select the HellocareSDK module.) or create it programmatically and add it to your view controller.

* To start the video room just call this method of VideoSessionView  ```startVideoSession(videoSessionListener:VideoSessionListener)``` method 

***  Hellocare SDK needs some permissions to work properly ** 

** Please add permissions request before call startSession method **

* The ```VideoSessionListener``` provide callback from the SDK to manage video session lifecycle.
* To cancel a connexion (before the video start) just call 

```
HellocareSDK.shared.cancelSession()
```


* To terminate the video session

```
HellocareSDK.shared.terminate()

```


# HellocareSDKBeta
